QUARTZ JOB SCHEDULER .NET, 2.2.4, Jul 27, 2014
-----------------------------------------------------------------

http://www.quartz-scheduler.net/

1. INTRODUCTION
----------------

This is the README file for Quartz.NET, .NET port of Java Quartz.

Quartz.NET is an opensource project aimed at creating a
free-for-commercial use Job Scheduler, with 'enterprise' features.

Licensed under the Apache License, Version 2.0 (the "License"); you may not 
use this file except in compliance with the License. You may obtain a copy 
of the License at 
 
    http://www.apache.org/licenses/LICENSE-2.0 

Also, to keep the legal people happy:

    This product includes software developed by the
    Apache Software Foundation (http://www.apache.org/)


2. KNOWN ISSUES
---------------

No known issues at the moment.


3. RELEASE INFO
----------------

This release corresponds to Java Quartz version 2.2.

For API documentation, please refer to Quartz.NET site: 

   http://apidoc.quartz-scheduler.net/
